import qualified SPC_Tests
import Test.Tasty (defaultMain)

main :: IO ()
main = defaultMain SPC_Tests.tests
