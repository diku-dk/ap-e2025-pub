-- | Omnibus test suite grouped by which task each test applies to.
module Tests (tests) where

import APL.AST
import APL.Eval
import APL.Monad
import APL.Parser
import BlockAutomaton.Rules
import BlockAutomaton.Server
import qualified BlockAutomaton.Simulation as Simulation
import Control.Monad
import Galapagos.Parser
import qualified Galapagos.Rules as Galapagos
import Test.Tasty (TestTree, testGroup)
import Test.Tasty.HUnit (assertFailure, testCase, (@?=))

parserTest :: String -> Exp -> TestTree
parserTest s e =
  testCase s $
    case parseAPL "input" s of
      Left err -> assertFailure err
      Right e' -> e' @?= e

parserTestFail :: String -> TestTree
parserTestFail s =
  testCase s $
    case parseAPL "input" s of
      Left _ -> pure ()
      Right e ->
        assertFailure $
          "Expected parse error but received this AST:\n" ++ show e

-- Evaluate APL expression where all effects are turned into errors.
evalPure :: Exp -> Either Error Val
evalPure e = interp $ eval [] e
  where
    interp (Pure x) = Right x
    interp (Free (ErrorOp err)) = Left err
    interp (Free _) = Left "unexpected effect"

testEquivalence :: (Eq obs, Show obs) => Rules state obs -> Int -> IO ()
testEquivalence rules steps = do
  let h = 8
      w = 8
      simulated =
        Simulation.observeGrid rules $
          (!! steps) $
            iterate (Simulation.stepGrid rules) $
              Simulation.initialGrid rules h w
  s <- startAutomaton rules h w
  replicateM_ steps $ stepAutomaton s
  real <- observeAutomaton s
  real @?= simulated

taskAtests :: TestTree
taskAtests =
  testGroup
    "Task A"
    [ testCase "0 elem {0}" $
        evalPure (Elem (CstInt 0) (Set [CstInt 0]))
          @?= Right (ValBool True),
      testCase "1 elem {0}" $
        evalPure (Elem (CstInt 1) (Set [CstInt 0]))
          @?= Right (ValBool False)
    ]

taskBtests :: TestTree
taskBtests =
  testGroup
    "Task B"
    [ parserTestFail "elem",
      parserTest "x elem y" $ Elem (Var "x") (Var "y")
    ]

taskCtests :: TestTree
taskCtests =
  testGroup
    "Task C"
    [ testCase "Smoothen(0)" $ testEquivalence smoothen 0,
      testCase "Smoothen(1)" $ testEquivalence smoothen 1,
      testCase "Smoothen(2)" $ testEquivalence smoothen 2
    ]

taskDtests :: TestTree
taskDtests = testGroup "Task D" []

taskEtests :: TestTree
taskEtests = testGroup "Task E" []

taskFtests :: TestTree
taskFtests = testGroup "Task F" []

tests :: TestTree
tests =
  testGroup
    "All tests"
    [ taskAtests,
      taskBtests,
      taskCtests,
      taskDtests,
      taskEtests,
      taskFtests
    ]
