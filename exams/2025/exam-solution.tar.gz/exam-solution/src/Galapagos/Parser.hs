module Galapagos.Parser (parseGalapagos) where

import APL.AST
import APL.Parser (pExp)
import Control.Monad (void)
import Data.Char (isAlphaNum, isDigit)
import Data.Void (Void)
import Galapagos.Rules
import Text.Megaparsec
  ( Parsec,
    choice,
    chunk,
    eof,
    errorBundlePretty,
    many,
    notFollowedBy,
    parse,
    satisfy,
    some,
    try,
  )
import Text.Megaparsec.Char (space)

type Parser = Parsec Void String

lexeme :: Parser a -> Parser a
lexeme p = p <* space

lString :: String -> Parser ()
lString s = lexeme $ void $ chunk s

lKeyword :: String -> Parser ()
lKeyword s = lexeme $ void $ try $ chunk s <* notFollowedBy (satisfy isAlphaNum)

signed :: Parser Int -> Parser Int
signed p =
  choice
    [ lString "-" *> (negate <$> p),
      p
    ]

lInt :: Parser Int
lInt =
  lexeme $ signed $ read <$> some (satisfy isDigit) <* notFollowedBy (satisfy isAlphaNum)

keywords :: [String]
keywords =
  [ "strategy",
    "width",
    "height",
    "startHP",
    "invBreedingChance",
    "maxHP",
    "lifespan",
    "invDensity",
    "payoffs"
  ]

lName :: Parser Name
lName = lexeme $ try $ do
  c <- satisfy constituent
  cs <- many $ satisfy constituent
  let v = c : cs
  if v `elem` keywords
    then fail "Unexpected keyword"
    else pure v
  where
    constituent c = isAlphaNum c || c `elem` "_-."

pLabeled :: String -> Parser a -> Parser a
pLabeled s p = lKeyword s *> lString "=" *> p

pWidth :: Parser Int
pWidth = pLabeled "width" lInt

pHeight :: Parser Int
pHeight = pLabeled "height" lInt

twoOf :: Parser a -> Parser [a]
twoOf p = do
  x <- p
  y <- p
  pure [x, y]

lColour :: Parser Colour
lColour = lexeme $ do
  _ <- chunk "#"
  r <- twoOf (satisfy hexDigit)
  g <- twoOf (satisfy hexDigit)
  b <- twoOf (satisfy hexDigit)
  pure $ RGB (read ("0x" <> r)) (read ("0x" <> g)) (read ("0x" <> b))
  where
    hexDigit c = c `elem` "0123456789abcdefABCDEF"

pStrategy :: Parser (Name, Colour, Exp)
pStrategy =
  (lKeyword "strategy")
    *> ( (,,)
           <$> lName
           <*> lColour
           <*> (lString "{" *> pExp <* lString "}")
       )

pPayoffs :: Parser (Int, Int, Int, Int)
pPayoffs =
  lString "("
    *> ( (,,,)
           <$> lInt
           <* lString ","
           <*> lInt
           <* lString ","
           <*> lInt
           <* lString ","
           <*> lInt
       )
    <* lString ")"

pParams :: Parser Params
pParams = modParams defaultParams
  where
    modParams params =
      choice
        [ do
            x <- pLabeled "startHP" lInt
            modParams $ params {startHP = x},
          do
            x <- pLabeled "invBreedingChance" lInt
            modParams $ params {invBreedingChance = x},
          do
            x <- pLabeled "maxHP" lInt
            modParams $ params {maxHP = x},
          do
            x <- pLabeled "lifespan" lInt
            modParams $ params {lifespan = x},
          do
            x <- pLabeled "invDensity" lInt
            modParams $ params {invDensity = x},
          do
            x <- pLabeled "payoffs" pPayoffs
            modParams $ params {payoffs = x},
          pure params
        ]

pConfig :: Parser Config
pConfig =
  ( choice
      [ Config <$> pHeight <*> pWidth,
        flip Config <$> pWidth <*> pHeight
      ]
  )
    <*> pParams
    <*> many pStrategy

parseGalapagos :: FilePath -> String -> Either String Config
parseGalapagos fname s = case parse (space *> pConfig <* eof) fname s of
  Left err -> Left $ errorBundlePretty err
  Right x -> Right x
