module Galapagos.Rules
  ( galapagos,
    Colour (..),
    Name,
    Strategy,
    Strategies,
    Config (..),
    Params (..),
    defaultParams,

    -- * For testing
    HP,
    Rounds,
    Finch (..),
    CellState (..),
    initial,
    breed,
    groom,
    age,
    kill,
    meet,
  )
where

import APL.AST (Exp)
import APL.Eval
import APL.Monad (EvalM, EvalOp (..), FinchID, Free (..))
import BlockAutomaton.Rules
import System.Random (StdGen, mkStdGen, uniform, uniformR)
import Prelude hiding (interact)

type HP = Int

type Rounds = Int

type Strategy = EvalM ()

type Name = String

data Colour = RGB Int Int Int deriving (Show, Eq)

type Strategies = [(Name, Colour, Exp)]

-- Parameters for the world simulation.
data Params = Params
  { -- The starting hit points of a new finch.
    startHP :: HP,
    -- The inverse of the breeding chance, i.e., to breed you must
    -- roll a 1 on a dice with this many sides.
    invBreedingChance :: Int,
    -- The maximum health points a finch can accumulate.
    maxHP :: HP,
    -- The lifespan of a new finch.
    lifespan :: Rounds,
    -- The inverse of the chance for a cell to be initially populated.
    invDensity :: Int,
    -- The three payoff parameters:
    --   a. the payoff of both finches grooming.
    --   b. the payoff of both finches ignoring.
    --   c. the payoff of being groomed but ignoring.
    --   d. the payoff of being ignored but grooming.
    payoffs :: (Int, Int, Int, Int)
  }
  deriving (Eq, Show)

defaultParams :: Params
defaultParams =
  Params
    { startHP = 14,
      invBreedingChance = 6,
      maxHP = 40,
      lifespan = 23,
      invDensity = 4,
      payoffs = (1, -2, 3, -4)
    }

payoff :: Params -> Bool -> Bool -> (Int, Int)
payoff (Params {payoffs = (a, b, c, d)}) = f
  where
    f True True = (a, a)
    f False False = (b, b)
    f True False = (d, c)
    f False True = (c, d)

data Finch = Finch
  { finchID :: Int,
    finchHP :: HP,
    finchRoundsLeft :: Rounds,
    finchColour :: Colour,
    finchStrategy :: Strategy,
    finchStrategyExp :: Exp
  }

-- A cell contains a random number generator and may also contain a finch.
data CellState = CellState
  { cellFinch :: Maybe Finch,
    cellRNG :: StdGen
  }

-- The first 'Int' is a seed for the RNG.
initial :: Int -> Config -> (Int, Int) -> CellState
initial s cfg (i, j) =
  let params = cfgParams cfg
      strategies = cfgStrategies cfg
      (start_alive, rng) =
        uniformR (1, invDensity params) (mkStdGen (s + i * 10000 + j))
      (fid, rng') = uniform rng
   in CellState
        { cellRNG = rng',
          cellFinch =
            if start_alive == 1
              then
                let (_, rgb, strategy) =
                      strategies !! ((i + j) `mod` length strategies)
                 in Just $
                      Finch
                        { finchID = fid,
                          finchHP = startHP params,
                          finchColour = rgb,
                          finchStrategy = eval [] strategy >> pure (),
                          finchStrategyExp = strategy,
                          finchRoundsLeft = lifespan params
                        }
              else Nothing
        }

decide :: FinchID -> Strategy -> Maybe (Bool, Bool -> Strategy)
decide fid (Free (MeetOp f)) = decide' $ f fid
  where
    decide' (Free (GroomOp c)) = Just (True, c)
    decide' (Free (IgnoreOp c)) = Just (False, c)
    decide' (Free (ErrorOp e)) = error e
    decide' (Free (MeetOp _)) = Nothing
    decide' Pure {} = Nothing
decide _ _ = Nothing

maybeBreed :: Params -> CellState -> Finch -> CellState
maybeBreed params cell parent =
  let (breeding, rng) = uniformR (1, invBreedingChance params) (cellRNG cell)
   in if breeding == 1
        then
          let (fid, rng') = uniform rng
           in cell
                { cellRNG = rng',
                  cellFinch =
                    Just
                      Finch
                        { finchHP = startHP params,
                          finchID = fid,
                          finchRoundsLeft = lifespan params,
                          finchColour = finchColour parent,
                          finchStrategy = eval [] (finchStrategyExp parent) >> pure (),
                          finchStrategyExp = finchStrategyExp parent
                        }
                }
        else cell {cellRNG = rng}

breed :: Params -> (CellState, CellState) -> (CellState, CellState)
breed params (other, me) =
  case (cellFinch other, cellFinch me) of
    (Nothing, Just me') -> (maybeBreed params other me', me)
    (Just other', Nothing) -> (other, maybeBreed params me other')
    _ -> (other, me)

meet :: Params -> (Finch, Finch) -> (Maybe Finch, Maybe Finch)
meet params (other_finch, me_finch) =
  let (other_finch', me_finch') =
        case ( decide (finchID me_finch) (finchStrategy other_finch),
               decide (finchID other_finch) (finchStrategy me_finch)
             ) of
          (Nothing, Nothing) ->
            (Nothing, Nothing)
          (Nothing, Just _) ->
            (Nothing, Just me_finch)
          (Just _, Nothing) ->
            (Just other_finch, Nothing)
          (Just (other_decision, other_c'), Just (me_decision, me_c')) ->
            let (other_gain, me_gain) = payoff params other_decision me_decision
             in ( Just $
                    other_finch
                      { finchHP = min (maxHP params) $ finchHP other_finch + other_gain,
                        finchStrategy = other_c' me_decision
                      },
                  Just $
                    me_finch
                      { finchHP = min (maxHP params) $ finchHP me_finch + me_gain,
                        finchStrategy = me_c' other_decision
                      }
                )
   in (other_finch', me_finch')

groom :: Params -> (CellState, CellState) -> (CellState, CellState)
groom params (other, me) =
  case (cellFinch other, cellFinch me) of
    ( Just other_finch,
      Just me_finch
      ) ->
        let (other_finch', me_finch') = meet params (other_finch, me_finch)
         in ( other {cellFinch = other_finch'},
              me {cellFinch = me_finch'}
            )
    _ ->
      (other, me)

age :: CellState -> CellState
age cell =
  case cellFinch cell of
    Nothing -> cell
    Just finch ->
      cell
        { cellFinch =
            Just $
              finch
                { finchRoundsLeft = finchRoundsLeft finch - 1
                }
        }

kill :: CellState -> CellState
kill cell =
  case cellFinch cell of
    Nothing -> cell
    Just finch ->
      if finchHP finch > 0 && finchRoundsLeft finch > 0
        then cell
        else cell {cellFinch = Nothing}

both :: (a -> b) -> (a, a) -> (b, b)
both f (x, y) = (f x, f y)

interact :: Params -> (CellState, CellState) -> (CellState, CellState)
interact params =
  both kill
    . both age
    . groom params
    . breed params

observe :: CellState -> Colour
observe cell = case cellFinch cell of
  Nothing -> black
  Just finch -> finchColour finch
  where
    black = RGB 0 0 0

data Config = Config
  { cfgHeight :: Int,
    cfgWidth :: Int,
    cfgParams :: Params,
    cfgStrategies :: [(Name, Colour, Exp)]
  }
  deriving (Eq, Show)

galapagos :: Int -> Config -> Rules CellState Colour
galapagos seed cfg =
  Rules
    { rulesInitial = initial seed cfg,
      rulesInteract = interact $ cfgParams cfg,
      rulesObserve = observe
    }
