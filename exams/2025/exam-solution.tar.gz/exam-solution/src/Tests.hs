-- | Omnibus test suite grouped by which task each test applies to.
module Tests (tests) where

import APL.AST
import APL.Eval
import APL.Monad
import APL.Parser
import BlockAutomaton.Rules
import BlockAutomaton.Server
import qualified BlockAutomaton.Simulation as Simulation
import Control.Monad
import Data.List (sort)
import Data.Maybe (isJust, isNothing)
import Galapagos.Parser
import qualified Galapagos.Rules as Galapagos
import System.Random (mkStdGen)
import Test.Tasty (TestTree, testGroup)
import Test.Tasty.HUnit (assertFailure, testCase, (@?=))

parserTest :: String -> Exp -> TestTree
parserTest s e =
  testCase s $
    case parseAPL "input" s of
      Left err -> assertFailure err
      Right e' -> e' @?= e

parserTestFail :: String -> TestTree
parserTestFail s =
  testCase s $
    case parseAPL "input" s of
      Left _ -> pure ()
      Right e ->
        assertFailure $
          "Expected parse error but received this AST:\n" ++ show e

galapagosParserTest :: String -> Galapagos.Config -> TestTree
galapagosParserTest s e =
  testCase s $
    case parseGalapagos "input" s of
      Left err -> assertFailure err
      Right e' -> e' @?= e

galapagosParserTestFail :: String -> TestTree
galapagosParserTestFail s =
  testCase s $
    case parseGalapagos "input" s of
      Left _ -> pure ()
      Right e ->
        assertFailure $
          "Expected parse error but received this AST:\n" ++ show e

invalid, cheater, samaritan, flipflop :: Galapagos.Finch
invalid =
  Galapagos.Finch
    { Galapagos.finchID = 0,
      Galapagos.finchHP = 10,
      Galapagos.finchRoundsLeft = 3,
      Galapagos.finchColour = Galapagos.RGB 0 0 0,
      Galapagos.finchStrategy =
        void $ eval mempty $ Galapagos.finchStrategyExp invalid,
      Galapagos.finchStrategyExp =
        CstBool False
    }
cheater =
  Galapagos.Finch
    { Galapagos.finchID = 0,
      Galapagos.finchHP = 10,
      Galapagos.finchRoundsLeft = 3,
      Galapagos.finchColour = Galapagos.RGB 0 0 0,
      Galapagos.finchStrategy =
        void $ eval mempty $ Galapagos.finchStrategyExp cheater,
      Galapagos.finchStrategyExp =
        ForLoop
          ("x", CstInt 0)
          ("i", CstInt 100)
          (Let "unused" Meet Ignore)
    }
samaritan =
  Galapagos.Finch
    { Galapagos.finchID = 0,
      Galapagos.finchHP = 20,
      Galapagos.finchRoundsLeft = 4,
      Galapagos.finchColour = Galapagos.RGB 0 0 0,
      Galapagos.finchStrategy =
        void $ eval mempty $ Galapagos.finchStrategyExp samaritan,
      Galapagos.finchStrategyExp =
        ForLoop
          ("x", CstInt 0)
          ("i", CstInt 100)
          (Let "unused" Meet Groom)
    }
flipflop =
  Galapagos.Finch
    { Galapagos.finchID = 0,
      Galapagos.finchHP = 20,
      Galapagos.finchRoundsLeft = 4,
      Galapagos.finchColour = Galapagos.RGB 0 0 0,
      Galapagos.finchStrategy =
        void $ eval mempty $ Galapagos.finchStrategyExp flipflop,
      Galapagos.finchStrategyExp =
        ForLoop
          ("x", CstInt 0)
          ("i", CstInt 100)
          (Let "unused" Meet (If (Eql (Mul (Div (Var "i") (CstInt 2)) (CstInt 2)) (Var "i")) Ignore Groom))
    }

defaultConfig :: Galapagos.Config
defaultConfig =
  Galapagos.Config
    { Galapagos.cfgHeight = 10,
      Galapagos.cfgWidth = 10,
      Galapagos.cfgParams = Galapagos.defaultParams,
      Galapagos.cfgStrategies =
        [ ( "samaritan",
            Galapagos.finchColour samaritan,
            Galapagos.finchStrategyExp samaritan
          ),
          ( "cheater",
            Galapagos.finchColour cheater,
            Galapagos.finchStrategyExp cheater
          ),
          ( "flipflop",
            Galapagos.finchColour flipflop,
            Galapagos.finchStrategyExp flipflop
          )
        ]
    }

-- Evaluate APL expression where all effects are turned into errors.
evalPure :: Exp -> Either Error Val
evalPure e = interp $ eval [] e
  where
    interp (Pure x) = Right x
    interp (Free (ErrorOp err)) = Left err
    interp (Free _) = Left "unexpected effect"

testEquivalence :: (Eq obs, Show obs) => Rules state obs -> Int -> IO ()
testEquivalence rules steps = do
  let h = 8
      w = 8
      simulated =
        Simulation.observeGrid rules $
          (!! steps) $
            iterate (Simulation.stepGrid rules) $
              Simulation.initialGrid rules h w
  s <- startAutomaton rules h w
  replicateM_ steps $ stepAutomaton s
  real <- observeAutomaton s
  real @?= simulated

setElems :: Val -> Maybe [Val]
setElems (ValSet vs) = Just $ sort vs
setElems _ = Nothing

taskAtests :: TestTree
taskAtests =
  testGroup
    "Task A"
    [ testCase "0 elem {0}" $
        evalPure (Elem (CstInt 0) (Set [CstInt 0]))
          @?= Right (ValBool True),
      testCase "1 elem {0}" $
        evalPure (Elem (CstInt 1) (Set [CstInt 0]))
          @?= Right (ValBool False),
      testCase "{1} elem {1}" $
        evalPure (Elem (Set [CstInt 1]) (Set [CstInt 1]))
          @?= Right (ValBool False),
      testCase "{1} union {1}" $
        fmap setElems (evalPure (Union (Set [CstInt 1]) (Set [CstInt 1])))
          @?= Right (Just [ValInt 1]),
      testCase
        "{1} union {2}"
        $ fmap setElems (evalPure (Union (Set [CstInt 1]) (Set [CstInt 2])))
          @?= Right (Just [ValInt 1, ValInt 2]),
      testCase
        "{1} without {2}"
        $ fmap setElems (evalPure (Without (Set [CstInt 1]) (Set [CstInt 2])))
          @?= Right (Just [ValInt 1]),
      testCase
        "{1} without {1}"
        $ fmap setElems (evalPure (Without (Set [CstInt 1]) (Set [CstInt 1])))
          @?= Right (Just [])
    ]

taskBtests :: TestTree
taskBtests =
  testGroup
    "Task B"
    [ parserTestFail "elem",
      parserTestFail "union",
      parserTestFail "elem",
      parserTest "x elem y" $
        Elem (Var "x") (Var "y"),
      parserTest "x elem y elem z" $
        Elem (Elem (Var "x") (Var "y")) (Var "z"),
      parserTest "x union y" $
        Union (Var "x") (Var "y"),
      parserTest "x union y union z" $
        Union (Var "x") (Union (Var "y") (Var "z")),
      parserTest "x without y" $
        Without (Var "x") (Var "y"),
      parserTest "x without y without z" $
        Without (Var "x") (Without (Var "y") (Var "z")),
      parserTest "x elem y == z" $
        Eql (Elem (Var "x") (Var "y")) (Var "z")
    ]

taskCtests :: TestTree
taskCtests =
  testGroup
    "Task C"
    [ testCase "Smoothen(0)" $ testEquivalence smoothen 0,
      testCase "Smoothen(1)" $ testEquivalence smoothen 1,
      testCase "Smoothen(2)" $ testEquivalence smoothen 2
    ]

both :: (a -> b) -> (a, a) -> (b, b)
both f (x, y) = (f x, f y)

taskDtests :: TestTree
taskDtests =
  testGroup
    "Task D"
    [ testCase "samaritan vs samaritan (1 step)" $
        fmap
          (both Galapagos.finchHP)
          (meetN 1 (samaritan, samaritan))
          @?= Just
            ( Galapagos.finchHP samaritan + 1,
              Galapagos.finchHP samaritan + 1
            ),
      testCase "cheater vs samaritan (1 step)" $
        fmap
          (both Galapagos.finchHP)
          (meetN 1 (cheater, samaritan))
          @?= Just
            ( Galapagos.finchHP cheater + 3,
              Galapagos.finchHP samaritan - 4
            ),
      testCase "cheater vs samaritan (2 steps)" $
        fmap
          (both Galapagos.finchHP)
          (meetN 2 (cheater, samaritan))
          @?= Just
            ( Galapagos.finchHP cheater + 6,
              Galapagos.finchHP samaritan - 8
            ),
      testCase "flipflop vs samaritan (2 steps)" $
        fmap
          (both Galapagos.finchHP)
          (meetN 2 (flipflop, samaritan))
          @?= Just
            ( Galapagos.finchHP flipflop + 4,
              Galapagos.finchHP samaritan - 3
            ),
      testCase "cheater vs invalid" $
        both
          (fmap Galapagos.finchHP)
          (Galapagos.meet Galapagos.defaultParams (cheater, invalid))
          @?= ( Just $ Galapagos.finchHP cheater,
                Nothing
              ),
      testCase "invalid vs cheater" $
        both
          (fmap Galapagos.finchHP)
          (Galapagos.meet Galapagos.defaultParams (invalid, cheater))
          @?= ( Nothing,
                Just $ Galapagos.finchHP cheater
              )
    ]
  where
    meetN 0 (a, b) = Just (a, b)
    meetN i (a, b) = case Galapagos.meet Galapagos.defaultParams (a, b) of
      (Just a', Just b') -> meetN (i - 1 :: Int) (a', b')
      _ -> Nothing

taskEtests :: TestTree
taskEtests =
  testGroup
    "Task E"
    [ galapagosParserTestFail "",
      galapagosParserTest "height=2 width=3" $
        Galapagos.Config 2 3 Galapagos.defaultParams [],
      galapagosParserTest "width=3 height=2" $
        Galapagos.Config 2 3 Galapagos.defaultParams []
    ]

taskFtests :: TestTree
taskFtests =
  testGroup
    "Task F"
    [ testGroup
        "initial"
        [ testCase "(0,0)" $
            isJust
              ( Galapagos.cellFinch (Galapagos.initial 42 defaultConfig (0, 0))
              )
              @?= True,
          testCase "(0,1)" $
            isNothing
              ( Galapagos.cellFinch (Galapagos.initial 42 defaultConfig (0, 1))
              )
              @?= True
        ],
      testGroup
        "breed"
        [ testCase "(empty,empty)" $
            both
              (isNothing . Galapagos.cellFinch)
              ( Galapagos.breed
                  Galapagos.defaultParams
                    { Galapagos.invBreedingChance = 1
                    }
                  (empty_cell, empty_cell)
              )
              @?= (True, True),
          testCase "(empty,full)" $
            let (a, b) =
                  Galapagos.breed
                    ( Galapagos.defaultParams
                        { Galapagos.invBreedingChance = 1
                        }
                    )
                    (empty_cell, cell samaritan)
             in case (Galapagos.cellFinch a, Galapagos.cellFinch b) of
                  (Just a', Just b') -> do
                    Galapagos.finchRoundsLeft a'
                      @?= Galapagos.lifespan Galapagos.defaultParams
                    Galapagos.finchHP a'
                      @?= Galapagos.startHP Galapagos.defaultParams
                    Galapagos.finchRoundsLeft b'
                      @?= Galapagos.finchRoundsLeft samaritan
                    Galapagos.finchHP b'
                      @?= Galapagos.finchHP samaritan
                  _ -> assertFailure "One of the cells ended up empty",
          testCase "(full,empty)" $
            let (a, b) =
                  Galapagos.breed
                    ( Galapagos.defaultParams
                        { Galapagos.invBreedingChance = 1
                        }
                    )
                    (cell samaritan, empty_cell)
             in case (Galapagos.cellFinch a, Galapagos.cellFinch b) of
                  (Just a', Just b') -> do
                    Galapagos.finchRoundsLeft b'
                      @?= Galapagos.lifespan Galapagos.defaultParams
                    Galapagos.finchHP b'
                      @?= Galapagos.startHP Galapagos.defaultParams
                    Galapagos.finchRoundsLeft a'
                      @?= Galapagos.finchRoundsLeft samaritan
                    Galapagos.finchHP a'
                      @?= Galapagos.finchHP samaritan
                  _ -> assertFailure "One of the cells ended up empty",
          testCase "(empty,full) (no breeding)" $
            let (a, b) =
                  Galapagos.breed
                    ( Galapagos.defaultParams
                        { Galapagos.invBreedingChance = 1000000000
                        }
                    )
                    (empty_cell, cell samaritan)
             in case (Galapagos.cellFinch a, Galapagos.cellFinch b) of
                  (Just _, _) -> assertFailure "Unexpected breeding"
                  (_, Nothing) -> assertFailure "Finch got removed"
                  _ -> pure (),
          testCase "(full,empty) (no breeding)" $
            let (a, b) =
                  Galapagos.breed
                    ( Galapagos.defaultParams
                        { Galapagos.invBreedingChance = 1000000000
                        }
                    )
                    (cell samaritan, empty_cell)
             in case (Galapagos.cellFinch a, Galapagos.cellFinch b) of
                  (_, Just __) -> assertFailure "Unexpected breeding"
                  (Nothing, _) -> assertFailure "Finch got removed"
                  _ -> pure ()
        ],
      testGroup
        "groom"
        [ testCase "(full,full)" $
            both
              (fmap (Galapagos.finchHP) . Galapagos.cellFinch)
              (Galapagos.groom Galapagos.defaultParams (cell samaritan, cell samaritan))
              @?= ( Just (Galapagos.finchHP samaritan + 1),
                    Just (Galapagos.finchHP samaritan + 1)
                  ),
          testCase "(empty,empty)" $
            both
              (isNothing . Galapagos.cellFinch)
              (Galapagos.groom Galapagos.defaultParams (empty_cell, empty_cell))
              @?= (True, True),
          testCase "(empty,full)" $
            both
              (fmap (Galapagos.finchHP) . Galapagos.cellFinch)
              (Galapagos.groom Galapagos.defaultParams (empty_cell, cell samaritan))
              @?= ( Nothing,
                    Just (Galapagos.finchHP samaritan)
                  ),
          testCase "(full,empty)" $
            both
              (fmap (Galapagos.finchHP) . Galapagos.cellFinch)
              (Galapagos.groom Galapagos.defaultParams (cell samaritan, empty_cell))
              @?= ( Just (Galapagos.finchHP samaritan),
                    Nothing
                  )
        ],
      testGroup
        "age"
        [ testCase "empty cell" $
            isNothing
              (Galapagos.cellFinch $ Galapagos.age empty_cell)
              @?= True,
          testCase "nonempty cell" $
            fmap
              Galapagos.finchRoundsLeft
              ( Galapagos.cellFinch $
                  Galapagos.age $
                    cell samaritan
              )
              @?= Just (Galapagos.finchRoundsLeft samaritan - 1)
        ],
      testGroup
        "kill"
        [ testCase "already empty" $
            isNothing
              ( Galapagos.cellFinch $
                  Galapagos.kill
                    ( Galapagos.CellState
                        { Galapagos.cellRNG = dummy_rng,
                          Galapagos.cellFinch = Nothing
                        }
                    )
              )
              @?= True,
          testCase "no rounds left" $
            isNothing
              ( Galapagos.cellFinch $
                  Galapagos.kill $
                    cell samaritan {Galapagos.finchRoundsLeft = 0}
              )
              @?= True,
          testCase "no HP left" $
            isNothing
              ( Galapagos.cellFinch $
                  Galapagos.kill $
                    cell $
                      samaritan {Galapagos.finchHP = 0}
              )
              @?= True
        ]
    ]
  where
    empty_cell =
      Galapagos.CellState
        { Galapagos.cellRNG = dummy_rng,
          Galapagos.cellFinch = Nothing
        }
    cell finch =
      Galapagos.CellState
        { Galapagos.cellRNG = dummy_rng,
          Galapagos.cellFinch = Just finch
        }
    dummy_rng = mkStdGen 0

tests :: TestTree
tests =
  testGroup
    "All tests"
    [ taskAtests,
      taskBtests,
      taskCtests,
      taskDtests,
      taskEtests,
      taskFtests
    ]
