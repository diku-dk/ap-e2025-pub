module BlockAutomaton.Server
  ( Automaton,
    startAutomaton,
    stepAutomaton,
    observeAutomaton,
  )
where

import BlockAutomaton.Rules
import Control.Concurrent
import Control.Monad (forM, forever, replicateM, when)
import GenServer

data CellCommandMsg obs
  = CellStep
  | CellStatus (ReplyChan obs)

data CellMsg state
  = CellShare state (Chan state)

data Junction state = Junction
  { junctionOut :: Chan (CellMsg state),
    junctionIn :: Chan (CellMsg state)
  }

data Neighbours a = Neighbours
  { haloN :: a,
    haloW :: a,
    haloE :: a,
    haloS :: a
  }
  deriving (Show)

cellLoop ::
  Chan (CellCommandMsg obs) ->
  Neighbours (Junction state) ->
  MargolusPos ->
  state ->
  ((state, state) -> (state, state)) ->
  (state -> obs) ->
  IO ()
cellLoop cmd_input neighbours initial_pos initial_state state_f obs_f =
  loop initial_state initial_pos
  where
    loop state pos = do
      msg <- receive cmd_input
      case msg of
        CellStatus rc -> do
          reply rc $ obs_f state
          loop state pos
        CellStep -> do
          state' <- case pos of
            UL -> do
              state' <- initiateWith state (haloE neighbours)
              initiateWith state' (haloS neighbours)
            LL -> do
              state' <- receiveFrom state (haloE neighbours)
              receiveFrom state' (haloN neighbours)
            UR -> do
              state' <- receiveFrom state (haloW neighbours)
              receiveFrom state' (haloS neighbours)
            LR -> do
              state' <- initiateWith state (haloW neighbours)
              initiateWith state' (haloN neighbours)
          loop state' (margolusShift pos)

    initiateWith state j = do
      rc <- newChan
      send (junctionOut j) $ CellShare state rc
      receive rc

    receiveFrom state j = do
      CellShare other_state rc <- receive $ junctionIn j
      let (here, there) = state_f (state, other_state)
      send rc there
      pure here

data AutomatonMsg obs
  = AutomatonStep
  | AutomatonObserve (ReplyChan [[obs]])

serverLoop ::
  Int ->
  Int ->
  Rules state obs ->
  Chan (AutomatonMsg obs) ->
  IO ()
serverLoop grid_height grid_width rules input = do
  cell_chans <-
    replicateM grid_height $
      replicateM grid_width $
        Neighbours <$> newChan <*> newChan <*> newChan <*> newChan

  let getChan (i, j) = cell_chans !! (i `mod` grid_height) !! (j `mod` grid_width)

      getJunctions (i, j) =
        let Neighbours n w e s = getChan (i, j)
         in Neighbours
              ( Junction
                  (haloS (getChan (i - 1, j)))
                  n
              )
              ( Junction
                  (haloE (getChan (i, j - 1)))
                  w
              )
              ( Junction
                  (haloW (getChan (i, j + 1)))
                  e
              )
              ( Junction
                  (haloN (getChan (i + 1, j)))
                  s
              )

  cs <- forM [0 .. grid_height - 1] $ \i ->
    forM [0 .. grid_width - 1] $ \j ->
      spawn $ \c ->
        cellLoop
          c
          (getJunctions (i, j))
          (margolusInitial (i, j))
          (rulesInitial rules (i, j))
          (rulesInteract rules)
          (rulesObserve rules)

  forever $ do
    msg <- receive input
    case msg of
      AutomatonStep ->
        mapM_ (mapM_ (`sendTo` CellStep)) cs
      AutomatonObserve rc ->
        reply rc =<< mapM (mapM (`requestReply` CellStatus)) cs

data Automaton obs = Automaton (Server (AutomatonMsg obs))

startAutomaton :: Rules state obs -> Int -> Int -> IO (Automaton obs)
startAutomaton rules height width = do
  when (width `mod` 2 /= 0 || width `mod` 2 /= 0) $
    error "startAutomaton: invalid grid size."
  server <- spawn $ serverLoop height width rules
  pure $ Automaton server

stepAutomaton :: Automaton obs -> IO ()
stepAutomaton (Automaton s) =
  sendTo s AutomatonStep

observeAutomaton :: Automaton obs -> IO [[obs]]
observeAutomaton (Automaton s) =
  requestReply s AutomatonObserve
